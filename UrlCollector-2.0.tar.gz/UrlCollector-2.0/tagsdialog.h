#ifndef TAGSDIALOG_H
#define TAGSDIALOG_H

#include <QDialog>
#include <QtGui>

class TagsDialog : public QDialog
{
    Q_OBJECT
    public:
        TagsDialog(QWidget *parent = 0);
};

#endif // TAGSDIALOG_H
