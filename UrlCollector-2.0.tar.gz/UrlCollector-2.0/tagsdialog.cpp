#include "tagsdialog.h"

TagsDialog::TagsDialog(QWidget *parent) : QDialog(parent)
{

}
