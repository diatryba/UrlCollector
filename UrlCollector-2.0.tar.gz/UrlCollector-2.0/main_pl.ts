<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>AddUrl</name>
    <message>
        <location filename="addurl.cpp" line="6"/>
        <source>Add new URL</source>
        <translation type="unfinished">Dodaj link</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="66"/>
        <source>Is favorite!</source>
        <translation type="unfinished">Ulubione!</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="26"/>
        <source>URL:</source>
        <translation type="unfinished">Link:</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="33"/>
        <source>Informtion about URL:</source>
        <translation type="unfinished">Informacje o linku:</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="40"/>
        <source>Tags:</source>
        <translation type="unfinished">Etykiety:</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="53"/>
        <source>Name of new tag</source>
        <translation type="unfinished">Nazwa nowej etykiety</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="57"/>
        <source>Press for add new tag</source>
        <translation type="unfinished">Kliknij aby dodać etykietę</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="124"/>
        <location filename="addurl.cpp" line="136"/>
        <source>add Url</source>
        <translation type="unfinished">Dodaj link</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="125"/>
        <source>Web-Link is exsists in DB!</source>
        <translation type="unfinished">Link już istnieje w bazie!</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="137"/>
        <source>Web-Link is not correct!</source>
        <translation type="unfinished">Link nie został wprowadzony poprawnie!</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="116"/>
        <source>Add Url</source>
        <translation type="unfinished">Dodaj link</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="117"/>
        <source>You must write web-link to cite!</source>
        <translation type="unfinished">Pole z adresem do serwisu powinno być wypełnione!</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="148"/>
        <location filename="addurl.cpp" line="155"/>
        <source>Add Tag</source>
        <translation type="unfinished">Dodaj etykietę</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="149"/>
        <source>Cannot add empty tag!</source>
        <translation type="unfinished">Nie można dodać pustej etykiety!</translation>
    </message>
    <message>
        <location filename="addurl.cpp" line="156"/>
        <source>Tag cannot contain character &apos;,&apos;!</source>
        <translation type="unfinished">Etykieta nie może zawierać znaku &apos;,&apos;!</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="39"/>
        <source>Enter text to find link</source>
        <translation type="unfinished">Wpisz zapytanie, aby wyszukać link
</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="41"/>
        <source>Find URL by info (Ctrl+F)</source>
        <translation type="unfinished">Znajdź link według opisu, etykiety lub nazwy strony (Ctrl+F)</translation>
    </message>
    <message>
        <source>Select file of BataBase</source>
        <translation type="obsolete">Wybierz plik bazy danych</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="89"/>
        <source>Select file of DataBase</source>
        <translation type="unfinished">Wybierz plik bazy danych</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="104"/>
        <source>Options</source>
        <translation type="unfinished">Konfiguracja</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="105"/>
        <source>Created new DataBese!</source>
        <translation type="unfinished">Nowa baza danych utworzona!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="129"/>
        <location filename="mainwindow.cpp" line="131"/>
        <source>Added automatically</source>
        <translation type="unfinished">Dodane automatycznie</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Link %1 
added to databse from clipboard</source>
        <translation type="unfinished">Link %1 \ndodano do bazy ze schowka</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="148"/>
        <location filename="mainwindow.cpp" line="963"/>
        <source>Rename tag</source>
        <translation type="unfinished">Zmień nazwę etykiety</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="149"/>
        <source>New tag name:</source>
        <translation type="unfinished">Nazwa nowej etykiety:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="161"/>
        <location filename="mainwindow.cpp" line="966"/>
        <source>Delete tag</source>
        <translation type="unfinished">Usuń etykietę</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="162"/>
        <source>Delete tag &apos;%1&apos; from all links?</source>
        <translation type="unfinished">Usunąć etykietę &apos;%1&apos; z wszystkich linków?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="215"/>
        <source>Quit from program</source>
        <translation type="unfinished">Wyjście z programu</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="216"/>
        <source>DataBase has been modified. Save DataBase of URL&apos;s?</source>
        <translation type="unfinished">Baza danych została zmieniona. Zapisać zmiany?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="287"/>
        <source>Select browser</source>
        <translation type="unfinished">Wybierz przeglądarkę internetową</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="327"/>
        <source>Open link.</source>
        <translation type="unfinished">Otwórz link</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="328"/>
        <source>List is empty</source>
        <translation type="unfinished">Lista jest pusta</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="367"/>
        <source>New database ...</source>
        <translation type="unfinished">Utwórz nową bazę danych ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="369"/>
        <source>Create new database</source>
        <translation type="unfinished">Utwórz nową bazę danych</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="372"/>
        <source>Open URL</source>
        <translation type="unfinished">Otwórz link</translation>
    </message>
    <message>
        <source>Open link in web-browser.</source>
        <translation type="obsolete">Otwórz adres URL w przeglądarce internetowej</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="382"/>
        <source>Open URL with ...</source>
        <translation type="unfinished">Otwórz link za pomocą
 ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="384"/>
        <source>Open link in other web-browser.</source>
        <translation type="unfinished">Otwórz link w innej przeglądarce</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="387"/>
        <location filename="mainwindow.cpp" line="392"/>
        <source>Add URL ...</source>
        <translation type="unfinished">Dodaj link ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="389"/>
        <location filename="mainwindow.cpp" line="393"/>
        <source>Add new URL in list.</source>
        <translation type="unfinished">Dodaj nowy link</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="396"/>
        <source>Delete URL ...</source>
        <translation type="unfinished">Usuń link ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="397"/>
        <location filename="mainwindow.cpp" line="421"/>
        <source>Delete URL from list.</source>
        <translation type="unfinished">Usuń link z bazy</translation>
    </message>
    <message>
        <source>Open URL with default web-browser...</source>
        <translation type="obsolete">Otwórz link w domyślnej przeglądarce
...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="401"/>
        <source>Open URL in with default web-browser.</source>
        <translation type="unfinished">Wyświetl link przy użyciu domyślnej przeglądarki</translation>
    </message>
    <message>
        <source>Show only favorite links.</source>
        <translation type="obsolete">Pokaż tylko ulubione łącza.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="374"/>
        <source>Open link in web-browser.</source>
        <translation type="unfinished">Otwórz link w przeglądarce</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="377"/>
        <source>Save all</source>
        <translation type="unfinished">Zapisz wszystko</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="379"/>
        <source>Save all DB</source>
        <translation type="unfinished">Zapisz całą bazę danych</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="400"/>
        <source>Open URL with default web-browser. (Ctrl+O)</source>
        <translation type="unfinished">Otwórz link w domyślnej przeglądarce (Ctrl+O)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="404"/>
        <source>Show only favorite links. (Alt+F)</source>
        <translation type="unfinished">Pokaż tylko ulubione linki (Alt+F)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="406"/>
        <source>Show only favorite links from base.</source>
        <translation type="unfinished">Pokaż tylko ulubione linki z bazy</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="410"/>
        <source>Edit data about URL ...</source>
        <translation type="unfinished">Edycja danych o adresie URL ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="411"/>
        <location filename="mainwindow.cpp" line="416"/>
        <location filename="mainwindow.cpp" line="873"/>
        <source>Edit data about URL.</source>
        <translation type="unfinished">Edycja danych o adresie URL</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="414"/>
        <source>Edit URL ...</source>
        <translation type="unfinished">Edytuj link
 ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="419"/>
        <location filename="mainwindow.cpp" line="582"/>
        <location filename="mainwindow.cpp" line="596"/>
        <source>Delete URL</source>
        <translation type="unfinished">Usuń link</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="428"/>
        <source>Exit</source>
        <translation type="unfinished">Wyjście</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="430"/>
        <source>Close program.</source>
        <translation type="unfinished">Zamknij program</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="433"/>
        <source>Options ...</source>
        <translation type="unfinished">Opcje ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="435"/>
        <source>program options.</source>
        <translation type="unfinished">Opcje programu</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="438"/>
        <source>About ...</source>
        <translation type="unfinished">O programie ...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="439"/>
        <source>About URL Collector.</source>
        <translation type="unfinished">O URL Collector.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="560"/>
        <location filename="mainwindow.cpp" line="800"/>
        <source>All tags</source>
        <translation type="unfinished">Wszystkie etykiety</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="583"/>
        <source>Do you want to delete this web-link?</source>
        <translation type="unfinished">Chcesz usunąć ten link?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="597"/>
        <source>No selected items</source>
        <translation type="unfinished">Brak wybranych linków</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="850"/>
        <source>Edit database</source>
        <translation type="unfinished">Edycja bazy danych</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="851"/>
        <source>Database is not opened!</source>
        <translation type="unfinished">Baza danych nie jest otwarta!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="874"/>
        <source>List is empty!</source>
        <translation type="unfinished">Lista jest pusta!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="903"/>
        <source>File</source>
        <translation type="unfinished">Plik</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="915"/>
        <source>Program</source>
        <translation type="unfinished">Program</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="918"/>
        <source>Help</source>
        <translation type="unfinished">Pomoc</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="924"/>
        <source>Welcome !!!</source>
        <translation type="unfinished">Witamy !!!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="929"/>
        <source>URL information</source>
        <translation type="unfinished">Informacje o linku</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="947"/>
        <source>Tags</source>
        <translation type="unfinished">Etykiety</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="975"/>
        <source>Copy link to clipboard</source>
        <translation type="unfinished">Skopiuj link do schowka</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="979"/>
        <source>Edit link...</source>
        <translation type="unfinished">Edytuj link...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="983"/>
        <source>is Favorite</source>
        <translation type="unfinished">Ulubiony link</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="988"/>
        <source>Delete link</source>
        <translation type="unfinished">Usuń link</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="997"/>
        <source>Open Url Collector</source>
        <translation type="unfinished">Otwórz Url Collector</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1001"/>
        <source>Quit</source>
        <translation type="unfinished">Wyjście</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="optionsdialog.cpp" line="58"/>
        <source>Monitoring clipboard</source>
        <translation type="unfinished">Monitorowanie schowka</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="59"/>
        <source>Turn ON monotoring clipboard for automatically add URL to database</source>
        <translation type="unfinished">Włącz śledzenie w schowku, aby automatycznie dodawać skopiowane łącza do bazy danych</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="10"/>
        <source>Options</source>
        <translation type="unfinished">Opcje</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="30"/>
        <location filename="optionsdialog.cpp" line="51"/>
        <source>Browse ...</source>
        <translation type="unfinished">Przeglądaj...</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="17"/>
        <source>Default web-browser:</source>
        <translation type="unfinished">Domyślna przeglądarka internetowa:</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="39"/>
        <source>Path to database:</source>
        <translation type="unfinished">Ścieżka do bazy danych:</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="66"/>
        <source>Autosave every </source>
        <translation type="unfinished">Automatyczne zapisywanie co </translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="72"/>
        <source>To turn OFF autosave setup 0 minutes interval</source>
        <oldsource>To turn OFF autosave setup 0 minutes value</oldsource>
        <translation type="unfinished">Aby wyłączyć automatyczne zapisywanie, ustaw interwał na 0 minut</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="84"/>
        <source>minutes</source>
        <translation type="unfinished">minut</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="106"/>
        <source>Select file of DataBase</source>
        <translation type="unfinished">Wybierz plik bazy danych</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="111"/>
        <source>Select default browser</source>
        <translation type="unfinished">Wybierz domyślną przeglądarkę internetową
</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="123"/>
        <source>Edit program Options</source>
        <translation type="unfinished">Edycja ustawień programu</translation>
    </message>
    <message>
        <location filename="optionsdialog.cpp" line="124"/>
        <source>You must select database!</source>
        <translation type="unfinished">Musisz wybrać plik bazy danych!</translation>
    </message>
</context>
</TS>
