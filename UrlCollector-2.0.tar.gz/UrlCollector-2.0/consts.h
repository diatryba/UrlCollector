#ifndef CONSTS_H
#define CONSTS_H

const QString PROGRAM_NAME = "URLCollector v2.0";
const QString PROGRAM_DIR = "/.urlcol";
const QString PROGRAM_CONFIG = "/.urlcol/url.config";
const QString LOCK_FILE = "/.urlcol/url.lock";

#endif // CONSTS_H
